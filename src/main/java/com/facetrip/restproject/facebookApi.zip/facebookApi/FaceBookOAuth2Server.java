package com.facetrip.restproject.facebookApi;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


public class FaceBookOAuth2Server {

    @Value("${facebook.access-token:https://graph.facebook.com/v6.0/oauth/access_token?}")
    private String oAuth2ServerUri;

    @Value("${facebook.redirect-uri:http://localhost:8080/user/login}")
    private String redirectUri;

    public String getUri(String clientId, String clientSecret, String code) {
        return oAuth2ServerUri+"client_id="+clientId+"&redirect_uri="+redirectUri
                +"&client_secret="+clientSecret+"&code="+code;
    }
}
