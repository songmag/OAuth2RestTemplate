package com.facetrip.restproject.facebookApi.Data;

public interface DataTransObject{
    String getSerializableString();
}
